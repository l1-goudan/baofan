Page({
  // 选择管理员身份
  onSelectAdmin() {
    // 保存用户角色为 'admin'
    wx.setStorage({
      key: 'userRole',
      data: 'manager',  // 设置角色为管理员
    });
    // 跳转到管理员页面
    wx.redirectTo({
      url: '/pages/manager/indexx'  // 管理员页面路径
    });
  },

  // 选择员工身份
  onSelectEmployee() {
    // 保存用户角色为 'employee'
    wx.setStorage({
      key: 'userRole',
      data: 'employee',  // 设置角色为员工
    });
    // 跳转到员工页面
    wx.redirectTo({
      url: '/pages/employee/index'  // 员工页面路径
    });
  }
});
