// pages/employee/index.js
Page({
  data: {
    mealInfo: {},
    countdown: ''
  },

  onLoad() {
    // 获取最新发布的餐次信息
    wx.cloud.database().collection('mealInfo').orderBy('date', 'desc').limit(1).get({
      success: res => {
        this.setData({
          mealInfo: res.data[0]
        });
        this.startCountdown(res.data[0].deadline);
      }
    });
  },

  startCountdown(deadline) {
    const now = new Date();
    const deadlineTime = new Date(deadline);
    const countdown = Math.max(0, deadlineTime - now);
    
    this.setData({
      countdown: this.formatTime(countdown)
    });
    
    setInterval(() => {
      this.setData({
        countdown: this.formatTime(countdown)
      });
    }, 1000);
  },

  formatTime(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    return `${hours}小时 ${minutes % 60}分钟 ${seconds % 60}秒`;
  },

  onRegister() {
    const { mealInfo } = this.data;
    wx.cloud.database().collection('mealRegistration').add({
      data: {
        mealId: mealInfo._id,
        userId: wx.getStorageSync('userId'), // 假设用户已经登录，并且我们存储了userId
        status: '已报名'
      },
      success(res) {
        wx.showToast({
          title: '报名成功',
          icon: 'success'
        });
      },
      fail(err) {
        wx.showToast({
          title: '报名失败',
          icon: 'none'
        });
      }
    });
  },

  onCancelRegister() {
    const { mealInfo } = this.data;
    wx.cloud.database().collection('mealRegistration').where({
      mealId: mealInfo._id,
      userId: wx.getStorageSync('userId')
    }).remove({
      success(res) {
        wx.showToast({
          title: '取消报名成功',
          icon: 'success'
        });
      },
      fail(err) {
        wx.showToast({
          title: '取消报名失败',
          icon: 'none'
        });
      }
    });
  }
});
