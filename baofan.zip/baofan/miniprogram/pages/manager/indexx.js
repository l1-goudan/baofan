// admin.js
Page({
  data: {
    date: "",  // 存储选择的日期
    mealTimeIndex: 0,  // 餐次的下拉框选择的索引
    mealTimes: ['早餐', '午餐', '晚餐'],  // 餐次选项
    staple: "",  // 主食
    side: "",    // 配菜
    soup: "",    // 汤
    deadlineTime: "",  // 报名截止时间
    deadline: "",  // 完整的报名截止时间
  },

  // 处理日期变化事件
  onDateChange(e) {
    const selectedDate = e.detail.value;
    this.setData({
      date: selectedDate,
      deadline: `${selectedDate} ${this.data.deadlineTime || '23:59'}`,  // 默认时间为23:59
    });
  },

  // 处理餐次变化事件
  onMealTimeChange(e) {
    this.setData({
      mealTimeIndex: e.detail.value,
    });
  },

  // 处理主食输入
  onStapleInput(e) {
    this.setData({
      staple: e.detail.value,
    });
  },

  // 处理配菜输入
  onSideInput(e) {
    this.setData({
      side: e.detail.value,
    });
  },

  // 处理汤输入
  onSoupInput(e) {
    this.setData({
      soup: e.detail.value,
    });
  },

  // 处理报名截止时间变化
  onTimeChange(e) {
    const selectedTime = e.detail.value;
    this.setData({
      deadlineTime: selectedTime,
      deadline: `${this.data.date} ${selectedTime}`,  // 合并日期和时间
    });
  },

  // 提交数据
  onSubmit() {
    // 提交数据到数据库
    wx.cloud.database().collection('meals').add({
      data: {
        date: this.data.date,
        mealTime: this.data.mealTimes[this.data.mealTimeIndex],  // 餐次
        staple: this.data.staple,
        side: this.data.side,
        soup: this.data.soup,
        deadline: this.data.deadline,  // 报名截止时间
      },
      success: res => {
        wx.showToast({
          title: '发布成功',
          icon: 'success',
        });
      },
      fail: err => {
        wx.showToast({
          title: '发布失败',
          icon: 'none',
        });
      }
    });
  }
});
