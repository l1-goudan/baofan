App({
  onLaunch() {
    // 获取本地存储中的用户角色
    wx.getStorage({
      key: 'userRole',
      success(res) {
        // 如果是管理员，跳转到管理员页面
        if (res.data === 'manager') {
          wx.redirectTo({
            url: '/pages/manager/indexx'
          });
        } else if (res.data === 'employee') {
          // 如果是员工，跳转到员工页面
          wx.redirectTo({
            url: '/pages/employee/index'
          });
        }
      },
      fail() {
        // 如果没有找到用户角色，则跳转到登录页面
        wx.redirectTo({
          url: '/pages/login/login'
        });
      }
    });
  }
});
